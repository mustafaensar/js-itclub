function DaireAlan(r) {
  let sonuc = Math.round(Math.PI) * Math.pow(r, 2);
  return sonuc;
}

function DortgenAlan(a, b) {
  let sonuc = (a * b);
  return sonuc;
}

function KupHacim(x) {
  let sonuc = Math.pow(x, 3);
  return sonuc;
}