let result = Functions.calculate("three", "two")

if (result == undefined) {
    output(
        ("<strong>Hello Aysecik :) :) :)</strong><br>Please write numbers between 1 - 10 <br>AND<br>Calculate according to the rules")   
    )    
}else{
    output(
        ("<strong>Hello Aysecik :) :) :)</strong><br><strong>Result: </strong>" + result)
    )
}

