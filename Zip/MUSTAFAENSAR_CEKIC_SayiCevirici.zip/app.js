let sayimiz = 3516351

let yazilisi = NumberToText(sayimiz);

output("<strong>Sayi:</strong><br>" + sayimiz + "<br><br>" + "<strong>Yazilisi:</strong><br>" + yazilisi)