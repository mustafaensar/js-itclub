function DaireAlan(r) {
  let sonuc = Math.round(Math.PI) * Math.pow(r, 2);
  return sonuc;
}

function DortgenAlan(a, b) {
  let sonuc = (a * b);
  return sonuc;
}

function DaireCevre(r) {
  let sonuc = (2 * (Math.round(Math.PI)) * r);
  return sonuc;
}

function DortgenCevre(a, b) {
  let sonuc = (2 * (a + b))
  return sonuc;
}

function KupHacim(x) {
  let sonuc = Math.pow(x, 3);
  return sonuc;
}

function KupAlan(x) {
  let sonuc = (x * 6);
  return sonuc;
}