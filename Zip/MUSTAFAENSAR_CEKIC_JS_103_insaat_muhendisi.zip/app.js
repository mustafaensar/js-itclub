let DaireAlani = DaireAlan(5);

console.log ("Daire Alani", DaireAlani); 

let DikdortgenAlani = DortgenAlan(8, 5);

console.log ("Dikdortgen Alani", DikdortgenAlani)

let DaireCevresi = DaireCevre(4);

console.log ("Daire Cevresi", DaireCevresi)

let DikdortgenCevresi = DortgenCevre(5, 6);

console.log ("Dikdortgen Cevresi", DikdortgenCevresi)

let KupunHacmi = KupHacim(4);

console.log ("Kupun Hacmi", KupunHacmi)

let KupunAlani = KupAlan(8);

console.log ("Kupun Alani", KupunAlani)