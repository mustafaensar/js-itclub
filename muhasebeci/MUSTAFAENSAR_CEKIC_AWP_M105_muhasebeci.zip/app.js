/**
 * PROGRAMIN GENEL ISLEYISI
 * 
 * Yeni bir kisi soldaki form doldurularak sagdaki tabloya eklenmeli
 * Kaydet butonuna basildiginda hem ekleme yapilmali hem de form alanlari temizlenmeli
 * Tablo isim, soyisim ya da kantona gore siralanabilir olmali
 * Tablonun ustunde bir arama kismi yapilip isim soyisim bilgileri ile arama yapilabilmeli
 * Arama sonrasinda ise sadece kriterlere uygun kayitlar gosterilmeli
 * 
 * 
 * 
 * ANALIZ KISMI
 * HTML icinde form eklenecek // yapildi
 * HTML icinde bir tablo eklenecek // yapildi
 * DOM üzerindeki formdan gelecek bilgiler butona basilarak bir data ya aktarilacak. // yapildi
 * Gelen bilgiler tabloda yazdirilacak // yapildi
 * Tablo basliklarina tiklanildigi zaman listeleme yapilacak // yapildi
 * Tablo icinde arama yapilabilecek // yapildi
 */


new Manager;