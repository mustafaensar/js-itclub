/**
 * Maktullerin adreslerini uretir.
 */
class Address{
    constructor(pStreet, pPlz, pOrt){
        this.street = pStreet;
        this.plz = pPlz;
        this.ort = pOrt;
    }
}