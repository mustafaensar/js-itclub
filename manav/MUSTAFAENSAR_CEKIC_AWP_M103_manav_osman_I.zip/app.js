const strawberryButton = document.querySelector('#strawberryButton');
strawberryButton.addEventListener('click', function(){
  newElement('strawberryInput', "Strawberry");
}, false);

const grapesButton = document.querySelector('#grapesButton');
grapesButton.addEventListener('click', function(){
  newElement('grapesInput', "Grapes");
}, false);

const pineappleButton = document.querySelector('#pineappleButton');
pineappleButton.addEventListener('click', function(){
  newElement('pineappleInput', "Pineaplle");
}, false);

const watermelonButton = document.querySelector('#watermelonButton');
watermelonButton.addEventListener('click', function(){
  newElement('watermelonInput', "Watermelon");
}, false);

const orangeButton = document.querySelector('#orangeButton');
orangeButton.addEventListener('click', function(){
  newElement('orangeInput', "Orange");
}, false);

const cherryButton = document.querySelector('#cherryButton');
cherryButton.addEventListener('click', function(){
  newElement('cherryInput', "Cherry");
}, false);